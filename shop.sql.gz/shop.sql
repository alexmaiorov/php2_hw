-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 27 2020 г., 11:50
-- Версия сервера: 10.3.13-MariaDB
-- Версия PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `login` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `id_product`, `name`, `price`, `count`, `login`) VALUES
(40, 7, 'Меркурий 115Ф', 5900, 1, 'admin'),
(41, 3, 'Меркурий 180Ф', 6500, 1, 'admin'),
(42, 2, 'Меркурий 130Ф', 5900, 1, 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `user_name` varchar(40) NOT NULL,
  `user_login` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `customer`
--

INSERT INTO `customer` (`id`, `user_name`, `user_login`, `email`, `phone`) VALUES
(1, 'Alexey', 'admin', 'dadufepoda@malboxe.c', '77777777'),
(3, 'qwerty', 'qwerty', 'qwerty@domain.com', '72222222');

-- --------------------------------------------------------

--
-- Структура таблицы `order_info`
--

CREATE TABLE `order_info` (
  `id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_login` varchar(40) NOT NULL,
  `product_name` varchar(40) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_info`
--

INSERT INTO `order_info` (`id`, `date`, `user_login`, `product_name`, `count`) VALUES
(27, '2020-02-20 17:59:45', 'admin', 'Меркурий 180Ф', 2),
(29, '2020-02-20 18:07:47', 'qwerty', 'Меркурий 180Ф', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `img_url` varchar(255) NOT NULL,
  `small_img_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `img_url`, `small_img_url`) VALUES
(1, 'Меркурий 115Ф', 'Знакомая большинству пользователей с 1997 года касса. Проверенный людьми и временем, надёжный кассовый аппарат позволяющий экономить ваши деньги при модернизации парка ККТ, при этом соответствовать новому закону о применении касс.', 5900, 'img/merkurij115f.jpg', 'img/small/merkurij115f.jpg'),
(2, 'Меркурий 130Ф', 'Мобильный и универсальный кассовый аппарат с GSM модулем. Онлайн касса Меркурий-130Ф соответствует всем требованиям 54-ФЗ. Предназначена для осуществления денежных расчетов с населением в сфере торговли и услуг.', 5900, 'img/merkurij130f.jpg', 'img/small/merkurij130f.jpg'),
(3, 'Меркурий 180Ф', 'Универсальный мобильный кассовый аппарат. Касса пользуется популярностью при выездной торговле, соответствует требованиям 54-ФЗ, внесена в реестр ККТ.', 6500, 'img/merkurij180f.jpg', 'img/small/merkurij180f.jpg'),
(9, 'aQsi 5', 'Автономная касса на базе системы Android со встроенным сканером шрих-кодов, терминалом для приема банковских карт (опционально) и бесплатным ПО. ', 11500, 'img/aqsi5f.jpg', 'img/small/aqsi5f.jpg'),
(10, 'Меркурий 185Ф', 'Мобильный и универсальный кассовый аппарат с GSM модулем. Онлайн касса Меркурий 185Ф соответствует требованиям 54-ФЗ, внесена в реестр ККТ.', 6900, 'img/merkurij185f.jpg', 'img/small/merkurij185f.jpg'),
(11, 'Кассатка 7', 'Мобильная онлайн касса с широким функционалом для малого и среднего бизнеса. Соответствует 54-ФЗ.', 16000, 'img/kassatka7.jpg', 'img/small/kassatka7.jpg'),
(12, 'Агат 1Ф', 'Агат 1Ф - удобная бюджетная онлайн касса, отлично подходящая для малого бизнеса. Легко программируется и проста в эксплуатации.', 5500, 'img/agat01f.jpg', 'img/small/agat01f.jpg'),
(13, 'Дримкас-Ф', 'Современная онлайн-касса в классическом исполнении, привычном для всех кассиров. Дримкас-Ф подключается к интернету, работает с операторами фискальных данных и передает чеки на электронную почту или абонентский номер покупателя.', 10900, 'img/', 'img/small/dreamkasf.jpg'),
(14, 'Меркурий 119Ф', 'Качественный фискальный регистратор на базе термопринтерного механизма фирмы Seiko.Бесшумная и быстрая печать чека. Легкое подключение к компьютеру через RS-232С или USB. Так же имеет Ethernet, Wi-Fi и Bluetooth модули.', 13000, 'img/merkurij119f.jpg', 'img/small/merkurij119f.jpg'),
(15, 'Viki Micro', 'Viki Micro – легкая и компактная онлайн касса с семидюймовым сенсорным дисплеем. ККТ Viki Micro позволяет проводить приемку и продажу алкоголя, а также автоматически заполнять алкогольный журнал по требованиям ЕГАИС. Соответствует 54-ФЗ.', 14490, 'img/viki-micro.jpg', 'img/small/viki-micro.jpg'),
(30, 'Viki Tower', 'Viki Tower - универсальный POS-терминал с сенсорным экраном, встроенным фискальным регистратором и кассовой программой. Базовая комплектация включает в себя считыватель магнитных карт, дисплей покупателя и модуль Wi-Fi. ', 66000, 'img/viki-tower.jpg', 'img/small/viki-tower.jpg'),
(31, 'Viki Mini', 'Компактная онлайн-касса с полным функционалом и сенсорным экраном. В корпус встроены принтер чеков, модуль Wi-Fi и считыватель магнитных карт. ', 29000, 'img/viki-mini.jpg', 'img/small/viki-mini.jpg'),
(32, 'АТОЛ FPrint-22ПТК', 'Прост и надежен в работе и обслуживании, соответствует закону 54-ФЗ. Модель прошла проверку временем и пользуется большим спросом. Одно из первых решений, имеющее возможность подключения к сети Интернет.', 22000, 'img/fprint_22_atol_pravo.jpg', 'img/small/fprint_22_atol_pravo.jpg'),
(33, 'ШТРИХ-М-01Ф', 'Новая модель фискального регистратора с автоматическим отрезчиком и широкой кассовой лентой. Соответствует требованиям Закона о применении ККТ. Подключается к компьютеру или POS-системе по RS-232 или USB.', 21000, 'img/shtrih-m-01-f.jpg', 'img/small/shtrih-m-01-f.jpg'),
(34, 'АТОЛ 30Ф', 'Бюджетное решение для предприятий малого и микро бизнеса с низкой пропускной способностью и малым бюджетом на автоматизацию. Соответствует 54-ФЗ.', 9900, 'img/atol-30f.jpg', 'img/small/atol-30f.jpg'),
(35, 'Атол 90Ф', 'Бюджетная онлайн касса АТОЛ 90Ф - это эргономичный дизайн без лишних функций и простота использования от надёжного производителя. Соответствует 54-ФЗ.', 8900, 'img/atol-90f.jpg', 'img/small/atol-90f.jpg'),
(36, 'АТОЛ 11Ф', 'Бюджетная модель фискального регистратора без автоматического отрезчика с широким функционалом. Экономия места на рабочем месте кассира в паре с современным дизайном.', 15900, 'img/atol-11f.jpg', 'img/small/atol-11f.jpg'),
(37, 'АМС-300Ф', 'Полноценное рабочее место кассира, не требующее дополнительных устройств и компьютера. Соответствует 54-ФЗ.', 18500, 'img/AMS-300F.jpg', 'img/small/AMS-300F.jpg'),
(38, 'КАСБИ-02Ф', 'Онлайн касса от надежного производителя. Касса сохранила лучшие черты ККМ семейства КАСБИ и осталась такой же простой и привычной в эксплуатации. Соответствует 54-ФЗ.', 11000, 'img/Kasbi_02f.jpg', 'img/small/Kasbi_02f.jpg'),
(39, 'Эвотор 7.2 Смарт-Терминал', 'Компактная бюджетная POS-система с обширным функционалом на базе планшета под управлением Android. Подойдет торговым точкам с малым и средним потоком клиентов, которым в работе не нужен сканер штрих кодов.', 15700, 'img/Evotor-smart-terminal.jpg', 'img/small/Evotor-smart-terminal.jpg'),
(40, 'Эвотор Стандарт', 'Эвотор Стандарт - комплектация онлайн кассы Эвотор с 1D-сканером штрих кодов. Компактная бюджетная POS-система с обширным функционалом на базе планшета под управлением Android.', 18700, 'img/Evotor-standart.jpg', 'img/small/Evotor-standart.jpg'),
(41, 'Эвотор Алко', 'Универсальный смарт-терминал Эвотор в комплекте со сканером двумерных штрих кодов и модулем УТМ от компании АТОЛ. Подходит для компаний, торгующих крепким алкоголем. Соответствует требованиям ЕГАИС.', 30490, 'img/Evotor-Alko.jpg', 'img/small/Evotor-Alko.jpg'),
(42, 'Эвотор 7.3 Смарт-Терминал', 'Онлайн касса Эвотор нового поколения – стильный смарт-терминал с обширным функционалом на базе планшета. Работает от аккумуляторов до 14 часов. Подойдет торговым точкам с малым и средним потоком клиентов, которым в работе не нужен сканер штрих кодов.', 18700, 'img/Evotor-Smart-Terminal-73.jpg', 'img/small/Evotor-Smart-Terminal-73.jpg'),
(43, 'Эвотор 7.3 Стандарт', 'Онлайн касса Эвотор нового поколения – стильный смарт-терминал с обширным функционалом на базе планшета, дополненный сканером штрих кодов. Работает от аккумуляторов до 14 часов.', 20800, 'img/Evotor-7-3-standart.jpg', 'img/small/Evotor-7-3-standart.jpg'),
(44, 'АТОЛ 20Ф', 'Модель предназначена для малого бизнеса с низкой и средней проходимостью. Соответствует 54-ФЗ.', 13000, 'img/atol-20f.jpg', 'img/small/atol-20f.jpg'),
(45, 'АТОЛ 50Ф', 'Модель предназначена для малого бизнеса с низкой и средней проходимостью. Соответствует 54-ФЗ.', 13500, 'img/atol-50f.jpg', 'img/small/atol-50f.jpg'),
(46, 'АТОЛ 91Ф', 'Автономная касса для предприятий малого бизнеса в сфере торговли и услуг, которая позволяет соответствовать требованиям 54-ФЗ без дорогостоящей полной автоматизации.', 9000, 'img/atol-91f.jpg', 'img/small/atol-91f.jpg'),
(47, 'АТОЛ 92Ф', 'Новая модель АТОЛ 92Ф – автономная онлайн касса для малого бизнеса. Дает возможность соблюдать требования 54-ФЗ без серьезных трудозатрат и больших вложений.', 7900, 'img/atol-92f.jpg', 'img/small/atol-92f.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `text` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `review`
--

INSERT INTO `review` (`id`, `firstname`, `lastname`, `email`, `text`, `date`) VALUES
(1, 'Иван', 'Иванов', 'ivanov@pochta.ru', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2020-02-17 11:22:45'),
(2, 'Петр', 'Петров', 'petpet@tojepochta.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ', '2020-02-17 11:22:45'),
(9, 'Алексей', 'Алексеев', 'primer@mail.ru', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2020-02-19 17:03:18');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `pass`, `date`, `admin`) VALUES
(1, 'admin', 'admin@domain.com', '21232f297a57a5a743894a0e4a801fc3', '2020-02-20 12:36:39', 1),
(11, 'qwerty', 'qwerty@domain.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2020-02-20 18:07:01', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `order_info`
--
ALTER TABLE `order_info`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT для таблицы `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `order_info`
--
ALTER TABLE `order_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT для таблицы `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
